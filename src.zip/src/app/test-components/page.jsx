"use client";

import { useMemo, useState, useSyncExternalStore } from "react";

import QuantityStepper from "@/components/common/QuantityStepper/QuantityStepper";
import ListingFormModal from "@/components/common/ListingFormModal/ListingFormModal";
import ListingDetailLayout from "@/components/common/ListingDetailLayout/ListingDetailLayout";

const STORAGE_KEY = "fav-photo-test-listing-v1";
const UPDATE_EVENT = "fav-photo-listing-updated";

const testCard = {
  id: 1,
  name: "노을 풍경 포토카드",
  description: "아름다운 노을 사진",
  method: "PHOTO",
  genre: "LANDSCAPE",
  price: 150,
};

const initialListing = {
  id: 10,
  photoCard: testCard,
  seller: {
    id: 2,
    nickname: "테스트판매자",
  },
  remainingQuantity: 3,
  price: 200,
  status: "ON_SALE",
  exchangeMethod: "CRAFT",
  exchangeGenre: "ANIMAL",
  exchangeDescription: "동물 포토카드와 교환 희망",
};

const buttonStyle = {
  padding: "12px 20px",
  backgroundColor: "#efff04",
  color: "#111111",
  border: "none",
  borderRadius: "8px",
  cursor: "pointer",
  fontWeight: "bold",
};

// 브라우저에 저장된 데이터 읽기
function getListingSnapshot() {
  try {
    return window.localStorage.getItem(STORAGE_KEY);
  } catch {
    return null;
  }
}

// 서버 렌더링에서는 기본 데이터 사용
function getServerListingSnapshot() {
  return null;
}

// localStorage 변경 감지
function subscribeToListing(callback) {
  window.addEventListener("storage", callback);
  window.addEventListener(UPDATE_EVENT, callback);

  return () => {
    window.removeEventListener("storage", callback);
    window.removeEventListener(UPDATE_EVENT, callback);
  };
}

// 같은 브라우저 탭에서도 변경 감지
function notifyListingUpdated() {
  window.dispatchEvent(new Event(UPDATE_EVENT));
}

export default function TestComponentsPage() {
  const [quantity, setQuantity] = useState(1);
  const [modalMode, setModalMode] = useState(null);
  const [result, setResult] = useState(null);

  // 저장된 판매글 데이터를 구독
  const storedListing = useSyncExternalStore(
    subscribeToListing,
    getListingSnapshot,
    getServerListingSnapshot,
  );

  // 저장 데이터가 있으면 복원, 없으면 기본값 사용
  const currentListing = useMemo(() => {
    if (!storedListing) {
      return initialListing;
    }

    try {
      const parsed = JSON.parse(storedListing);

      if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
        return initialListing;
      }

      return {
        ...initialListing,
        ...parsed,
        photoCard: testCard,
        seller: initialListing.seller,
      };
    } catch {
      return initialListing;
    }
  }, [storedListing]);

  // 판매 등록 / 수정 테스트
  async function handleSubmit(data) {
    const updatedListing = {
      ...currentListing,
      remainingQuantity: data.quantity,
      price: data.price,
      exchangeMethod: data.exchangeMethod,
      exchangeGenre: data.exchangeGenre,
      exchangeDescription: data.exchangeDescription,
    };

    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedListing));

      notifyListingUpdated();
    } catch (error) {
      console.error("테스트 데이터 저장 실패", error);
      return;
    }

    setResult({
      mode: modalMode,
      ...data,
    });

    setModalMode(null);
  }

  // 테스트 데이터 초기화
  function handleReset() {
    try {
      localStorage.removeItem(STORAGE_KEY);
      notifyListingUpdated();
    } catch (error) {
      console.error("테스트 데이터 초기화 실패", error);
      return;
    }

    setResult(null);
    setModalMode(null);
  }

  return (
    <main
      style={{
        padding: "40px",
        minHeight: "100vh",
        backgroundColor: "#111111",
        color: "#ffffff",
      }}
    >
      <h1
        style={{
          fontSize: "32px",
          marginBottom: "40px",
        }}
      >
        공통 컴포넌트 테스트
      </h1>

      {/* 1. QuantityStepper */}
      <section style={{ marginBottom: "50px" }}>
        <h2
          style={{
            fontSize: "24px",
            marginBottom: "20px",
          }}
        >
          1. QuantityStepper
        </h2>

        <QuantityStepper
          value={quantity}
          min={1}
          max={5}
          onChange={setQuantity}
        />

        <p style={{ marginTop: "20px" }}>현재 선택한 수량: {quantity}장</p>
      </section>

      {/* 2. ListingFormModal */}
      <section style={{ marginBottom: "50px" }}>
        <h2
          style={{
            fontSize: "24px",
            marginBottom: "20px",
          }}
        >
          2. ListingFormModal
        </h2>

        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
            gap: "12px",
          }}
        >
          <button
            type="button"
            style={buttonStyle}
            onClick={() => setModalMode("create")}
          >
            판매 등록 테스트
          </button>

          <button
            type="button"
            style={buttonStyle}
            onClick={() => setModalMode("edit")}
          >
            판매 수정 테스트
          </button>

          <button
            type="button"
            style={{
              ...buttonStyle,
              backgroundColor: "#555555",
              color: "#ffffff",
            }}
            onClick={handleReset}
          >
            테스트 데이터 초기화
          </button>
        </div>

        {result && (
          <div style={{ marginTop: "24px" }}>
            <h3>마지막 제출 데이터</h3>

            <pre
              style={{
                padding: "20px",
                marginTop: "12px",
                backgroundColor: "#333333",
                borderRadius: "8px",
                overflowX: "auto",
              }}
            >
              {JSON.stringify(result, null, 2)}
            </pre>
          </div>
        )}
      </section>

      {/* 3. ListingDetailLayout */}
      <section style={{ marginBottom: "50px" }}>
        <h2
          style={{
            fontSize: "24px",
            marginBottom: "20px",
          }}
        >
          3. ListingDetailLayout
        </h2>

        <ListingDetailLayout
          listing={currentListing}
          actions={
            <button
              type="button"
              style={buttonStyle}
              onClick={() => setModalMode("edit")}
            >
              판매글 수정 테스트
            </button>
          }
          exchangeContent={
            <div>
              <h3>교환 제안 영역</h3>
              <p>교환 담당 팀원의 컴포넌트가 연결될 예정입니다.</p>
            </div>
          }
        />
      </section>

      {/* 판매 등록 / 수정 모달 */}
      {modalMode && (
        <ListingFormModal
          key={modalMode}
          card={testCard}
          listing={modalMode === "edit" ? currentListing : null}
          maxQuantity={5}
          onSubmit={handleSubmit}
          onClose={() => setModalMode(null)}
        />
      )}
    </main>
  );
}
